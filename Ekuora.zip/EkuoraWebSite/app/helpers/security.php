<?php
/**
 * security.php - Aliases y utilidades de seguridad
 */

/**
 * Alias para logSeguridad
 */
function logSecurityEvent($evento, $descripcion = null, $usuario_id = null, $nivel = 'info')
{
    return logSeguridad($evento, $descripcion, $usuario_id, $nivel);
}

/**
 * Verificar token CSRF (wrapper para validarToken con redirección)
 */
function verificarToken($token)
{
    if (!validarToken($token)) {
        logSecurityEvent('csrf_invalido', 'Token CSRF inválido o expirado', null, 'warning');
        setFlash('error', 'Token de seguridad inválido. Por favor, intente nuevamente.');

        // Redirigir al referer o al dashboard
        $referer = $_SERVER['HTTP_REFERER'] ?? BASE_URL . 'dashboard';
        header("Location: " . $referer);
        exit();
    }
}
