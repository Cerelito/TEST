<?php
// app/models/Perfil.php - Modelo de Perfil

class Perfil
{
    private $conn;
    private $table = 'perfiles';

    public function __construct()
    {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    /**
     * Obtener todos los perfiles
     */
    public function getAll()
    {
        $stmt = $this->conn->query("
            SELECT p.*,
                   (SELECT COUNT(*) FROM usuarios WHERE perfil_id = p.id AND deleted_at IS NULL) as total_usuarios
            FROM {$this->table} p
            WHERE p.deleted_at IS NULL
            ORDER BY p.created_at ASC
        ");

        $perfiles = $stmt->fetchAll();

        // Cargar permisos para cada perfil (formato simplificado para el ID de perfil)
        foreach ($perfiles as &$perfil) {
            $id = $perfil['id'] ?? $perfil['Id'] ?? null;
            if ($id) {
                $perfil['permisos'] = $this->getPermisosFull($id);
            } else {
                $perfil['permisos'] = [];
            }
        }

        return $perfiles;
    }

    /**
     * Obtener permisos con estructura completa para un perfil
     */
    public function getPermisosFull($perfil_id)
    {
        $stmt = $this->conn->prepare("
            SELECT p.clave as codigo, p.nombre
            FROM permisos p
            INNER JOIN perfil_permisos pp ON p.id = pp.permiso_id
            WHERE pp.perfil_id = :perfil_id
        ");

        $stmt->execute([':perfil_id' => $perfil_id]);

        return $stmt->fetchAll();
    }

    /**
     * Obtener perfil por ID
     */
    public function getById($id)
    {
        $stmt = $this->conn->prepare("
            SELECT p.*,
                   (SELECT COUNT(*) FROM usuarios WHERE perfil_id = p.id AND deleted_at IS NULL) as total_usuarios
            FROM {$this->table} p
            WHERE p.id = :id AND p.deleted_at IS NULL
            LIMIT 1
        ");

        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Obtener permisos de un perfil
     */
    public function getPermisos($perfil_id)
    {
        $stmt = $this->conn->prepare("
            SELECT p.clave
            FROM permisos p
            INNER JOIN perfil_permisos pp ON p.id = pp.permiso_id
            WHERE pp.perfil_id = :perfil_id
        ");

        $stmt->execute([':perfil_id' => $perfil_id]);

        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    /**
     * Obtener IDs de permisos de un perfil
     */
    public function getPermisosIds($perfil_id)
    {
        $stmt = $this->conn->prepare("
            SELECT permiso_id
            FROM perfil_permisos
            WHERE perfil_id = :perfil_id
        ");

        $stmt->execute([':perfil_id' => $perfil_id]);

        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    /**
     * Obtener todos los permisos del sistema
     */
    public function getTodosLosPermisos()
    {
        $stmt = $this->conn->query("
            SELECT * FROM permisos
            ORDER BY modulo, clave
        ");

        return $stmt->fetchAll();
    }

    /**
     * Obtener permisos agrupados por módulo
     */
    public function getPermisosAgrupados()
    {
        $permisos = $this->getTodosLosPermisos();

        $modulos = [
            'dashboard' => [
                'nombre' => 'Dashboard',
                'descripcion' => 'Panel principal',
                'icono' => 'bi-speedometer2',
                'permisos' => []
            ],
            'proveedores' => [
                'nombre' => 'Proveedores',
                'descripcion' => 'Gestión de proveedores',
                'icono' => 'bi-building',
                'permisos' => []
            ],
            'solicitudes' => [
                'nombre' => 'Solicitudes',
                'descripcion' => 'Solicitudes de cambios',
                'icono' => 'bi-file-earmark-text',
                'permisos' => []
            ],
            'usuarios' => [
                'nombre' => 'Usuarios',
                'descripcion' => 'Gestión de usuarios',
                'icono' => 'bi-people',
                'permisos' => []
            ],
            'perfiles' => [
                'nombre' => 'Perfiles',
                'descripcion' => 'Roles y permisos',
                'icono' => 'bi-shield-check',
                'permisos' => []
            ],
            'catalogos' => [
                'nombre' => 'Catálogos',
                'descripcion' => 'Bancos, CÍAs, Regímenes',
                'icono' => 'bi-list-ul',
                'permisos' => []
            ],
            'configuracion' => [
                'nombre' => 'Configuración',
                'descripcion' => 'Configuración del sistema',
                'icono' => 'bi-gear',
                'permisos' => []
            ],
            'reportes' => [
                'nombre' => 'Reportes',
                'descripcion' => 'Reportes y exportaciones',
                'icono' => 'bi-graph-up',
                'permisos' => []
            ]
        ];

        foreach ($permisos as $permiso) {
            $modulo = $permiso['modulo'] ?? $permiso['Modulo'] ?? 'otros';
            if (isset($modulos[$modulo])) {
                $modulos[$modulo]['permisos'][] = $permiso;
            } else {
                $modulos['otros']['permisos'][] = $permiso;
            }
        }

        return $modulos;
    }

    /**
     * Crear perfil
     */
    public function create($datos)
    {
        try {
            $this->conn->beginTransaction();

            $stmt = $this->conn->prepare("
                INSERT INTO {$this->table} (nombre, descripcion)
                VALUES (:nombre, :descripcion)
            ");

            $stmt->execute([
                ':nombre' => $datos['nombre'],
                ':descripcion' => $datos['descripcion'] ?? null
            ]);

            $perfil_id = $this->conn->lastInsertId();

            // Asignar permisos
            if (!empty($datos['permisos'])) {
                $this->asignarPermisos($perfil_id, $datos['permisos']);
            }

            $this->conn->commit();

            logSeguridad('perfil_creado', "Perfil {$datos['nombre']} creado", null, 'info');

            return $perfil_id;

        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Error al crear perfil: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Actualizar perfil
     */
    public function update($id, $datos)
    {
        try {
            $this->conn->beginTransaction();

            $stmt = $this->conn->prepare("
                UPDATE {$this->table}
                SET nombre = :nombre,
                    descripcion = :descripcion,
                    updated_at = NOW()
                WHERE id = :id
            ");

            $stmt->execute([
                ':id' => $id,
                ':nombre' => $datos['nombre'],
                ':descripcion' => $datos['descripcion'] ?? null
            ]);

            // Actualizar permisos
            $this->limpiarPermisos($id);

            if (!empty($datos['permisos'])) {
                $this->asignarPermisos($id, $datos['permisos']);
            }

            $this->conn->commit();

            logSeguridad('perfil_actualizado', "Perfil ID: $id actualizado", null, 'info');

            return true;

        } catch (Exception $e) {
            $this->conn->rollBack();
            error_log("Error al actualizar perfil: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Eliminar perfil (soft delete)
     */
    public function delete($id)
    {
        // Verificar que no tenga usuarios asignados
        $perfil = $this->getById($id);
        if ($perfil && $perfil['total_usuarios'] > 0) {
            return false;
        }

        $stmt = $this->conn->prepare("
            UPDATE {$this->table}
            SET deleted_at = NOW()
            WHERE id = :id
        ");

        $result = $stmt->execute([':id' => $id]);

        if ($result) {
            logSeguridad('perfil_eliminado', "Perfil ID: $id eliminado", null, 'warning');
        }

        return $result;
    }

    /**
     * Asignar permisos a un perfil
     */
    private function asignarPermisos($perfil_id, $permisos_claves)
    {
        foreach ($permisos_claves as $clave) {
            // Obtener ID del permiso
            $stmt = $this->conn->prepare("SELECT id FROM permisos WHERE clave = :clave LIMIT 1");
            $stmt->execute([':clave' => $clave]);
            $permiso = $stmt->fetch();

            if ($permiso) {
                $stmt = $this->conn->prepare("
                    INSERT IGNORE INTO perfil_permisos (perfil_id, permiso_id)
                    VALUES (:perfil_id, :permiso_id)
                ");

                $stmt->execute([
                    ':perfil_id' => $perfil_id,
                    ':permiso_id' => $permiso['id']
                ]);
            }
        }
    }

    /**
     * Limpiar permisos de un perfil
     */
    private function limpiarPermisos($perfil_id)
    {
        $stmt = $this->conn->prepare("DELETE FROM perfil_permisos WHERE perfil_id = :perfil_id");
        $stmt->execute([':perfil_id' => $perfil_id]);
    }

    /**
     * Verificar si existe nombre
     */
    public function existeNombre($nombre, $exclude_id = null)
    {
        $sql = "SELECT id FROM {$this->table} WHERE nombre = :nombre AND deleted_at IS NULL";

        if ($exclude_id) {
            $sql .= " AND id != :exclude_id";
        }

        $stmt = $this->conn->prepare($sql);
        $params = [':nombre' => $nombre];

        if ($exclude_id) {
            $params[':exclude_id'] = $exclude_id;
        }

        $stmt->execute($params);

        return $stmt->rowCount() > 0;
    }
}
