<?php
require_once ROOT_PATH . 'views/layouts/icons.php';
ob_start();
?>
<div class="og-page">
  <div class="og-page__header">
    <div>
      <h1 class="og-page__title">Dashboard</h1>
      <p class="og-page__sub">Bienvenido, <?= htmlspecialchars($auth->userName()) ?></p>
    </div>
  </div>

  <!-- Métricas -->
  <div class="og-metrics">
    <div class="og-metric">
      <span class="og-metric__label">Proyectos activos</span>
      <span class="og-metric__val"><?= $stats['proyectos'] ?></span>
    </div>
    <div class="og-metric og-metric--warn">
      <span class="og-metric__label">Vencen hoy</span>
      <span class="og-metric__val"><?= $stats['tareas_hoy'] ?></span>
    </div>
    <div class="og-metric og-metric--danger">
      <span class="og-metric__label">Vencidas</span>
      <span class="og-metric__val"><?= $stats['vencidas'] ?></span>
    </div>
    <div class="og-metric og-metric--info">
      <span class="og-metric__label">Mis tareas activas</span>
      <span class="og-metric__val"><?= $stats['mis_tareas'] ?></span>
    </div>
  </div>

  <div class="og-two-col">

    <!-- Mis tareas -->
    <div class="og-card">
      <div class="og-card__head">
        <h2 class="og-card__title">Mis tareas pendientes</h2>
        <a href="<?= Router::url('tasks') ?>" class="og-link">Ver todas</a>
      </div>
      <?php if (empty($misTareas)): ?>
        <p class="og-empty">Sin tareas pendientes.</p>
      <?php else: ?>
        <ul class="og-tasklist">
          <?php foreach ($misTareas as $t): ?>
          <li class="og-tasklist__item">
            <span class="og-badge" style="background:<?= htmlspecialchars($t['estatus_color']) ?>22;color:<?= htmlspecialchars($t['estatus_color']) ?>">
              <?= htmlspecialchars($t['estatus']) ?>
            </span>
            <div class="og-tasklist__info">
              <a href="<?= Router::url('tasks/edit', $t['id']) ?>" class="og-tasklist__name">
                <?= htmlspecialchars($t['titulo']) ?>
              </a>
              <span class="og-tasklist__meta">
                <?= htmlspecialchars($t['proyecto']) ?> ·
                <?php if (!empty($t['fecha_fin'])): ?>
                  <?php $left = DateHelper::daysLeft($t['fecha_fin']); ?>
                  <span class="<?= $left < 0 ? 'og-overdue' : ($left <= 3 ? 'og-soon' : '') ?>">
                    <?= $left < 0 ? 'Vencida ' . abs($left) . 'd' : "Vence en {$left}d" ?>
                  </span>
                <?php endif; ?>
              </span>
            </div>
            <div class="og-progress">
              <div class="og-progress__bar" style="width:<?= $t['progreso'] ?>%"></div>
            </div>
          </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>

    <!-- Proyectos -->
    <div class="og-card">
      <div class="og-card__head">
        <h2 class="og-card__title">Proyectos</h2>
        <?php if ($auth->isGestor()): ?>
        <a href="<?= Router::url('projects/create') ?>" class="og-btn og-btn--sm">
          <?= ogIcon('plus', 14) ?> Nuevo
        </a>
        <?php endif; ?>
      </div>
      <?php if (empty($proyectos)): ?>
        <p class="og-empty">Sin proyectos aún.</p>
      <?php else: ?>
        <ul class="og-projlist">
          <?php foreach ($proyectos as $p): ?>
          <li class="og-projlist__item">
            <span class="og-projlist__dot" style="background:<?= htmlspecialchars($p['color']) ?>"></span>
            <div class="og-projlist__info">
              <a href="<?= Router::url('tasks') ?>?proyecto_id=<?= $p['id'] ?>" class="og-projlist__name">
                <?= htmlspecialchars($p['nombre']) ?>
              </a>
              <span class="og-projlist__meta"><?= $p['total_tareas'] ?> tareas · <?= $p['avance'] ?? 0 ?>% avance</span>
            </div>
            <div class="og-progress" style="width:80px">
              <div class="og-progress__bar" style="width:<?= $p['avance'] ?? 0 ?>%;background:<?= htmlspecialchars($p['color']) ?>"></div>
            </div>
          </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>

  </div>
</div>
<?php
$content   = ob_get_clean();
$pageTitle = 'Dashboard';
include ROOT_PATH . 'views/layouts/main.php';
