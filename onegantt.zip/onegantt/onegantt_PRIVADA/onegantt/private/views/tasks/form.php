<?php
require_once ROOT_PATH . 'views/layouts/icons.php';
$editing = !empty($task);
ob_start();
?>
<div class="og-page">
  <div class="og-page__header">
    <a href="<?= Router::url('tasks') ?>" class="og-back">&larr; Tareas</a>
    <h1 class="og-page__title"><?= $editing ? 'Editar tarea' : 'Nueva tarea' ?></h1>
  </div>

  <?php if (!empty($error)): ?>
    <div class="og-alert og-alert--error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <div class="og-two-col og-two-col--70-30">

    <!-- Columna izquierda: datos de la tarea -->
    <div>
      <div class="og-card">
        <form method="POST" enctype="multipart/form-data" class="og-form" id="task-form">
          <?= $csrfField ?>

          <div class="og-form__group">
            <label for="titulo">Título <span class="og-req">*</span></label>
            <input type="text" id="titulo" name="titulo" required maxlength="255"
                   value="<?= htmlspecialchars($task['titulo'] ?? $_POST['titulo'] ?? '') ?>">
          </div>

          <div class="og-form__group">
            <label for="descripcion">Descripción</label>
            <textarea id="descripcion" name="descripcion" rows="4"><?= htmlspecialchars($task['descripcion'] ?? '') ?></textarea>
          </div>

          <div class="og-form__row">
            <div class="og-form__group">
              <label for="proyecto_id">Proyecto <span class="og-req">*</span></label>
              <select id="proyecto_id" name="proyecto_id" required>
                <option value="">— Seleccionar —</option>
                <?php foreach ($proyectos as $p): ?>
                <option value="<?= $p['id'] ?>"
                  <?= ($task['proyecto_id'] ?? $_POST['proyecto_id'] ?? '') == $p['id'] ? 'selected' : '' ?>>
                  <?= htmlspecialchars($p['nombre']) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="og-form__group">
              <label for="padre_id">Tarea padre (opcional)</label>
              <select id="padre_id" name="padre_id">
                <option value="">— Ninguna (tarea madre) —</option>
                <?php foreach ($allTasks as $at):
                  if ($editing && $at['id'] == $task['id']) continue; ?>
                <option value="<?= $at['id'] ?>"
                  <?= ($task['padre_id'] ?? '') == $at['id'] ? 'selected' : '' ?>>
                  <?= htmlspecialchars($at['titulo']) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="og-form__row">
            <div class="og-form__group">
              <label for="estatus_id">Estatus</label>
              <select id="estatus_id" name="estatus_id">
                <?php foreach ($statuses as $s): ?>
                <option value="<?= $s['id'] ?>"
                  <?= ($task['estatus_id'] ?? 1) == $s['id'] ? 'selected' : '' ?>>
                  <?= htmlspecialchars($s['nombre']) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="og-form__group">
              <label for="prioridad">Prioridad</label>
              <select id="prioridad" name="prioridad">
                <option value="1" <?= ($task['prioridad'] ?? 2) == 1 ? 'selected' : '' ?>>Baja</option>
                <option value="2" <?= ($task['prioridad'] ?? 2) == 2 ? 'selected' : '' ?>>Media</option>
                <option value="3" <?= ($task['prioridad'] ?? 2) == 3 ? 'selected' : '' ?>>Alta</option>
              </select>
            </div>
          </div>

          <div class="og-form__row">
            <div class="og-form__group">
              <label for="asignado_a">Asignar a</label>
              <select id="asignado_a" name="asignado_a">
                <option value="">— Sin asignar —</option>
                <?php foreach ($usuarios as $u): ?>
                <option value="<?= $u['id'] ?>"
                  <?= ($task['asignado_a'] ?? '') == $u['id'] ? 'selected' : '' ?>>
                  <?= htmlspecialchars($u['nombre']) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="og-form__row">
            <div class="og-form__group">
              <label for="fecha_inicio">Fecha inicio</label>
              <input type="date" id="fecha_inicio" name="fecha_inicio"
                     value="<?= DateHelper::toInput($task['fecha_inicio'] ?? '') ?>">
            </div>
            <div class="og-form__group">
              <label for="fecha_fin">Fecha fin</label>
              <input type="date" id="fecha_fin" name="fecha_fin"
                     value="<?= DateHelper::toInput($task['fecha_fin'] ?? '') ?>">
            </div>
          </div>

          <?php if ($editing): ?>
          <div class="og-form__group">
            <label for="progreso">Progreso: <span id="prog-label"><?= $task['progreso'] ?>%</span></label>
            <input type="range" id="progreso" name="progreso" min="0" max="100" step="5"
                   value="<?= $task['progreso'] ?>"
                   oninput="document.getElementById('prog-label').textContent=this.value+'%'">
          </div>
          <?php endif; ?>

          <!-- Adjuntos -->
          <div class="og-form__group">
            <label><?= ogIcon('clip', 14) ?> Adjuntar archivos (máx. 5MB c/u)</label>
            <input type="file" name="adjuntos[]" multiple
                   accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.gif,.txt,.csv">
          </div>

          <div class="og-form__actions">
            <a href="<?= Router::url('tasks') ?>" class="og-btn og-btn--ghost">Cancelar</a>
            <button type="submit" class="og-btn">
              <?= $editing ? 'Guardar cambios' : 'Crear tarea' ?>
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- Columna derecha: notas y adjuntos (solo al editar) -->
    <?php if ($editing): ?>
    <div>

      <!-- Adjuntos existentes -->
      <?php if (!empty($adjuntos)): ?>
      <div class="og-card og-card--sm">
        <h3 class="og-card__title">Archivos adjuntos</h3>
        <ul class="og-filelist">
          <?php foreach ($adjuntos as $a): ?>
          <li class="og-filelist__item">
            <?= ogIcon('clip', 14) ?>
            <a href="<?= UPLOAD_URL . htmlspecialchars($a['nombre_disco']) ?>" target="_blank">
              <?= htmlspecialchars($a['nombre_orig']) ?>
            </a>
            <small class="og-muted"><?= round($a['tamano']/1024, 1) ?>KB</small>
          </li>
          <?php endforeach; ?>
        </ul>
      </div>
      <?php endif; ?>

      <!-- Notas -->
      <div class="og-card og-card--sm">
        <h3 class="og-card__title">Notas</h3>
        <form method="POST" action="<?= Router::url('tasks/edit', $task['id']) ?>" class="og-note-form">
          <?= $csrfField ?>
          <input type="hidden" name="titulo" value="<?= htmlspecialchars($task['titulo']) ?>">
          <input type="hidden" name="proyecto_id" value="<?= $task['proyecto_id'] ?>">
          <input type="hidden" name="estatus_id" value="<?= $task['estatus_id'] ?>">
          <input type="hidden" name="prioridad" value="<?= $task['prioridad'] ?>">
          <input type="hidden" name="progreso" value="<?= $task['progreso'] ?>">
          <textarea name="nota_nueva" rows="2" placeholder="Escribe una nota..."></textarea>
          <button type="submit" class="og-btn og-btn--sm">Agregar</button>
        </form>

        <?php if (!empty($notas)): ?>
        <ul class="og-notes">
          <?php foreach ($notas as $n): ?>
          <li class="og-notes__item">
            <div class="og-notes__head">
              <strong><?= htmlspecialchars($n['autor']) ?></strong>
              <span class="og-muted"><?= DateHelper::format($n['created_at'], 'd/m/Y H:i') ?></span>
            </div>
            <p><?= nl2br(htmlspecialchars($n['nota'])) ?></p>
          </li>
          <?php endforeach; ?>
        </ul>
        <?php else: ?>
          <p class="og-empty">Sin notas aún.</p>
        <?php endif; ?>
      </div>

    </div>
    <?php endif; ?>

  </div>
</div>
<?php
$content   = ob_get_clean();
$pageTitle = $editing ? 'Editar tarea' : 'Nueva tarea';
include ROOT_PATH . 'views/layouts/main.php';
