<?php
$rootPath = getenv('ROOT_PATH') ?: '/home1/erickedu/Controladores-Apotema/onegantt/';
define('ROOT_PATH', rtrim($rootPath, '/') . '/');

require_once ROOT_PATH . 'config/app.php';

spl_autoload_register(function (string $class): void {
    foreach (['core', 'models', 'controllers', 'helpers', 'exports'] as $dir) {
        // Probar con nombre original (ej: Auth.php)
        $file1 = ROOT_PATH . $dir . '/' . $class . '.php';
        if (file_exists($file1)) { require_once $file1; return; }
        
        // Probar todo en minúsculas (ej: auth.php)
        $file2 = ROOT_PATH . $dir . '/' . strtolower($class) . '.php';
        if (file_exists($file2)) { require_once $file2; return; }
    }
});

$auth  = new Auth();
$route = trim($_GET['route'] ?? '', '/');
$route = $route === '' ? 'dashboard' : $route;

if (!preg_match('/^[a-zA-Z0-9_\/\-]+$/', $route)) {
    http_response_code(400); die('Ruta inválida.');
}

$parts = explode('/', $route);

$routeMap = [
    'login'          => ['AuthController',      'login'],
    'logout'         => ['AuthController',      'logout'],
    'dashboard'      => ['DashboardController', 'index'],
    'projects'       => ['ProjectController',   'index'],
    'projects/create'=> ['ProjectController',   'create'],
    'projects/edit'  => ['ProjectController',   'edit'],
    'projects/delete'=> ['ProjectController',   'delete'],
    'tasks'          => ['TaskController',      'index'],
    'tasks/create'   => ['TaskController',      'create'],
    'tasks/edit'     => ['TaskController',      'edit'],
    'tasks/gantt'    => ['TaskController',      'gantt'],
    'tasks/delete'   => ['TaskController',      'delete'],
    'reports'        => ['ReportController',    'index'],
    'reports/export' => ['ReportController',    'export'],
    'reports/import' => ['ReportController',    'import'],
];

$key   = count($parts) >= 2 ? $parts[0].'/'.$parts[1] : $parts[0];
$param = $parts[2] ?? null;

if (!isset($routeMap[$key])) {
    http_response_code(404);
    include ROOT_PATH . 'views/layouts/404.php'; exit;
}

[$ctrl, $action] = $routeMap[$key];
(new $ctrl($auth))->$action($param);
